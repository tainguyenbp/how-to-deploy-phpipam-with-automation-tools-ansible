<?php
require( dirname(__FILE__) . '/../../admin/subnets/index.php');
